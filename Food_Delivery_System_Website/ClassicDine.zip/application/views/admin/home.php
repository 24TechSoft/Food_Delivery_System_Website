<html>
<body>
<h1>Hello</h1>
<a href="<?php echo base_url();?>User/Logout">Log Out</a>
</body>
</html>